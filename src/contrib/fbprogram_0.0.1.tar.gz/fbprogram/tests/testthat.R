library(testthat)
library(fbprogram)

test_check("fbprogram")
