fbglobal variables
==================
