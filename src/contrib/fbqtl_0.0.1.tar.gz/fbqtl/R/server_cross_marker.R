#' server_cross_marker
#'
#' Constructs table
#'
#' @param input shinyserver input
#' @param output shinyserver output
#' @param session shinyserver session
#' @param dom target dom element name
#' @param values reactive values
#' @author Reinhard Simon
#' @export
server_cross_marker <- function(input, output, session, dom="hot_cross_marker", values){
  setHot_cross_marker = function(x) values[[dom]] = x
  roots = shinyFiles::getVolumes("Page File (F:)")
  #print(roots)
  shinyFiles::shinyFileChoose(input, 'cross_marker_files', session = session,
                              #roots=roots,
                              roots = roots,
                              filetypes = c('rds', 'mq'))

  shiny::observeEvent(input$cross_marker_files, {
    #fn = fbglobal::fname_cross_marker(input$module_crop)
    fn <- as.character(
      shinyFiles::parseFilePaths(roots, input$cross_marker_files)$datapath[1]
    )
    #print(paste0("Importing ... ", fn))
    tbl <- fbqtl::import_cross_marker_table(fn, input$cross_marker_crop)
    #print(tbl)
    setHot_cross_marker(tbl)
    #print("ok")
  }
  )


  output$module_cross_marker <- shiny::renderUI({
    if (is.null(values[["hot_cross_marker_crops"]])) {
      values[["hot_cross_marker_crops"]] <- fbcrops::get_crop_table()
    }
    crops <- values[["hot_cross_marker_crops"]]$crop_name
    shiny::selectInput("cross_marker_crop", NULL, choices = crops, width = '50%')
  })


  output$cross_marker_butSave <- shiny::renderUI({
    shiny::actionButton("saveCrossMarkerButton", "Save", inline = TRUE)
  })

  output$cross_marker_butExport <- shiny::renderUI({
    shiny::downloadButton("downloadCrossMarkerData", "Export")
  })



  shiny::observeEvent(input$saveCrossMarkerButton, ({
    if (!is.null(input[[dom]])) {
      table_cross_marker = rhandsontable::hot_to_r(input[[dom]])
      #print(table_cross_markers)
      #print(input$module_crop)
      fbqtl::post_cross_marker_table(table_cross_marker,
                                  input$cross_marker_crop)
      #print("saved!")
    }
  })
  )


  output$hot_cross_markers = rhandsontable::renderRHandsontable({
    shiny::withProgress(message = 'Loading table', {
      #list_name <- input$module_name
      #print(input$module_crop)
      DF_cross_marker <- fbqtl::get_cross_marker_table(crop = input$cross_marker_crop,
                                                       name = "data.loc.rds" )
      #print(DF_cross_marker)
      if(!is.null(DF_cross_marker)){
        setHot_cross_markers(DF_cross_marker)
        rh <- rhandsontable::rhandsontable(DF_cross_marker,   stretchH = "all")
        rhandsontable::hot_table(rh, highlightCol = TRUE, highlightRow = TRUE)
      } else {
        NULL
      }
    })
  })

  output$downloadModuleData <- shiny::downloadHandler(
    filename = function() {
      paste(input$cross_marker_crop,"_cross_marker_",
            Sys.Date(), '.csv', sep = '')
    },
    content = function(con) {
      write.csv( values[["hot_cross_marker"]], con, row.names = FALSE)
    }
  )

}
