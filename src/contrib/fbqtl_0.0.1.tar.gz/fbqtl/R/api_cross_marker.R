#' get a table of markers from a cross.
#'
#' Based on MapQTL format.
#'
#' @param crop string
#' @param name string (without spaces up to 20 characters)
#' @export
get_cross_marker_table <- function(crop, name){
  fp <- fbglobal::fname_cross_marker(crop)
  # lf <- list.files(fp, full.names = T)
  # if(length(lf) == 0) return(NULL)
  lf <- file.path(fp, "data.loc.rds")
  read_cross(lf, type = "rds")
}

#' post a table of markers from a cross.
#'
#' Based on MapQTL format.
#'
#' @param table_cross string
#' @param crop string (without spaces up to 20 characters)
#' @export
post_cross_marker_table <- function(table_cross, crop){
  fp <- fbglobal::fname_cross_marker(crop)
  fp <- file.path(fp, paste0(table_cross$meta$name, ".loc.rds"))
  saveRDS(table_cross, fp)
}

#' Imports a cross marker table locally.
#'
#' Posts a data.frame containing cross marker data and also returns the table or NULL.
#'
#' @author Reinhard Simon
#' @param file  a file path as string
#' @param crop character
#' @return dataframe
#' @export
import_cross_marker_table <- function(file, crop){
  if (stringr::str_detect(file, ".loc")) {
    tbl <- read_cross(file)
  }

  post_cross_marker_table(tbl, crop = crop)
  tbl
}


