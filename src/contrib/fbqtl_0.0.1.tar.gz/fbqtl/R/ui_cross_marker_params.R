#' UI material list paramters
#'
#' An interface to parameters
#'
#' @param name character
#' @author Reinhard Simon
#' @export
ui_cross_marker_params <- function(name = "resource_cross_marker"){
  shiny::conditionalPanel(
    paste0("input.menu == '",name,"'"),
    shiny::uiOutput("cross_marker_crop", inline = TRUE),

    shiny::HTML("<center>"),
    shinyBS::bsAlert("saveCrossMarkerAlert"),
    shiny::uiOutput("cross_marker_butSave", inline = TRUE),
    #shiny::actionButton("butNewModule", "New", inline = TRUE),
    shinyFiles::shinyFilesButton('cross_marker_files', 'Import',
                                 'Please select a file', FALSE ),
    shiny::uiOutput("cross_marker_butExport", inline = TRUE),
    shiny::HTML("</center>")
  )
}
