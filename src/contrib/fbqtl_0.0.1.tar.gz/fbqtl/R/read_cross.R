read_cross <- function(file_path = "data.loc", type="mapqtl"){
  if(type == "mapqtl"){
    meta = readLines(file_path, n = 4)
    for(i in 1:4){
      n = stringr::str_split(meta[i], " = ")[[1]]
      meta[i] = list(n[2])
      names(meta)[[i]] = n[1]
    }

    data = readr::read_tsv(file_path, col_names = FALSE, skip = 5)
    n = ncol(data) - 3
    names(data) <- c("locus", "segregation", "phase",paste0("G", 1:n))
    attr(data, "meta") = meta
  }
  if (type == "rds") {
    data = readRDS(file_path)
  }

  data
}

 # x=read_cross("data.loc")
 # saveRDS(x, file = "data.loc.rds")
