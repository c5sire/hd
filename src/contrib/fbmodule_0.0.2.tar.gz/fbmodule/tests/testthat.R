library(testthat)
library(fbmodule)

test_check("fbmodule", reporter = "tap")
