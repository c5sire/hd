#' fbmodule.
#'
#' @name fbmodule
#' @example inst/examples/ex_package.R
#' @docType package
NULL
