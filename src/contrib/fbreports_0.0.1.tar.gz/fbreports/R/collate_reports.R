#' collate a list of reports
#'
#' Assumes certain convention on location ('inst/rmd') and naming of reports
#' (.rmd files starting with 'child-' will be ignored).
#'
#' @export
#' @param packages a vector of package names where to search for reports
#' @return data.frame
collate_reports <- function(packages){

}


# interactive_report
# try out child report
