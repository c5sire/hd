library(testthat)
library(fbprstages)

test_check("fbprstages")
