#' Demo application
#'
#' Builds a shinydashboard app from re-usable application elements
#'
#' @author Reinhard Simon
#' @export
run_sites <- function(){
  shiny::runApp(system.file("app_sites", package="fbsites"))
}
