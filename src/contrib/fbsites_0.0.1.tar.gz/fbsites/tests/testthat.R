library(testthat)
library(fbsites)

test_check("fbsites")
