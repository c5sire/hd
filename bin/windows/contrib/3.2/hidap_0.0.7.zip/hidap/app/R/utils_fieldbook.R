# get_fieldbook_list <- function(crop){
#   fp <- file.path(fbglobal::fname_fieldbook(), crop)
#   list.files(fp)
# }

# get_fieldbook_table <-function(crop, fieldbook){
#   fp <- file.path(fbglobal::fname_fieldbook(), crop, fieldbook)
#   fieldbook <- readRDS(fp)
#   fieldbook
# }
