library(shiny)
library(shinydashboard)
library(rhandsontable)
library(fbglobal)
library(fbqtl)
library(shinyBS)
library(shinyFiles)

tabNameS <- "resource_cross_marker"


server <- function(input, output, session) {
  values = shiny::reactiveValues()
  fbqtl::server_cross_marker(input, output, session, values = values)
}

ui <- dashboardPage(skin = "yellow",
                    dashboardHeader(title = "Demo Cross Marker"),
                    dashboardSidebar(width = 350,
                     menuItem("Resources",
                      sidebarMenu(id = "menu",
                        menuSubItem("Cross marker", icon = icon("book"),
                                    tabName = tabNameS),
                        fbqtl::ui_cross_marker_params()
                      )
                     )
                    ),
                    dashboardBody(
                      tabItems(
                        fbqtl::ui_cross_marker(name = tabNameS)
                      )
                    )
)

shinyApp(ui = ui, server = server)
