library(fbmodule)

# Create a dummy sample table

tbl <- get_module_table("potato")

