The function `invalidateLater()` can be used to invalidate an observer or
reactive expression in a given number of milliseconds. In this example, the
output `currentTime` is updated every second, so it shows the current time
on a second basis.
